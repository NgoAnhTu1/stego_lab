import cv2
import numpy as np
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os
import json
import glob
import shutil
from typing import List, Tuple

def _generate_key(password: str) -> bytes:
    salt = b'fixed_salt_for_consistency'
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def message_to_bits(message: str, password: str) -> list:
    key = _generate_key(password)
    f = Fernet(key)
    encrypted_message = f.encrypt(message.encode())
    
    message_with_markers = "START" + encrypted_message.decode() + "END"
    
    bytes_array = [ord(c) for c in message_with_markers]
    
    checksum = sum(bytes_array) & 0xFF
    bytes_array.append(checksum)
    
    bits = []
    for b in bytes_array:
        for i in range(8):
            bits.append(str((b >> i) & 1))
    
    return bits

def save_bits_to_file(bits: list, filename: str):
    with open(filename, 'w') as f:
        f.write("".join(bits))

def extract_frames(video_path: str, output_dir: str):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video file {video_path}")
        return []

    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    frames = []
    frame_count = 0
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_filename = os.path.join(output_dir, f"frame_{frame_count:04d}.png")
        cv2.imwrite(frame_filename, frame)
        frames.append(frame_filename)
        frame_count += 1
    
    cap.release()
    return frames

def _get_bit_planes(frame: np.ndarray) -> list:
    if len(frame.shape) == 3:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        gray = frame

    bit_planes = []
    for i in range(8):
        bit_plane = (gray >> i) & 1
        bit_planes.append(bit_plane)
    return bit_planes

def _calculate_complexity(block: np.ndarray) -> float:
    n = block.shape[0]
    k = 0
    
    for i in range(n):
        for j in range(n-1):
            if block[i, j] != block[i, j+1]:
                k += 1
    
    for i in range(n-1):
        for j in range(n):
            if block[i, j] != block[i+1, j]:
                k += 1
    
    denominator = (2 * n * (2 * n - 1))
    if denominator == 0:
        return 0.0
    return k / denominator

def _find_noisy_blocks(frame: np.ndarray, block_size: int = 8, threshold: float = 0.3) -> list:
    bit_planes = _get_bit_planes(frame)
    bit_plane = bit_planes[0]
    h, w = bit_plane.shape
    noisy_blocks = []
    
    for i in range(0, h - block_size + 1, block_size):
        for j in range(0, w - block_size + 1, block_size):
            block = bit_plane[i:i+block_size, j:j+block_size]
            alpha = _calculate_complexity(block)
            if alpha > threshold:
                noisy_blocks.append((i, j))
    
    return noisy_blocks

def process_frames_for_complexity(input_frames_dir: str, block_size: int = 8, threshold: float = 0.3, output_json_path: str = 'complexity.json'):
    frame_paths = sorted(glob.glob(os.path.join(input_frames_dir, 'frame_*.png')))
    if not frame_paths:
        print(f"Error: No frames found in {input_frames_dir}")
        return

    noisy_blocks_for_json = {}

    for frame_idx, frame_path in enumerate(frame_paths):
        frame = cv2.imread(frame_path)
        if frame is None:
            print(f"Warning: Could not read frame {frame_path}, skipping.")
            continue
        
        bit_planes = _get_bit_planes(frame)
        bit_plane = bit_planes[0]

        h, w = bit_plane.shape
        current_frame_noisy_blocks_coords = [] 
        
        for i in range(0, h - block_size + 1, block_size):
            for j in range(0, w - block_size + 1, block_size):
                block_data = bit_plane[i:i+block_size, j:j+block_size]
                
                if block_data.size == 0:
                    continue

                alpha = _calculate_complexity(block_data)
                is_noisy = alpha > threshold

                if is_noisy:
                    current_frame_noisy_blocks_coords.append((i, j))
        
        noisy_blocks_for_json[str(frame_idx)] = current_frame_noisy_blocks_coords
        
    with open(output_json_path, 'w') as f:
        json.dump(noisy_blocks_for_json, f, indent=4)

class BPCS_Embedder:
    def __init__(self):
        pass

    def load_bits_from_file(self, filename: str) -> List[str]:
        with open(filename, 'r') as f:
            bits_str = f.read().strip()
        filtered_bits = [char for char in bits_str if char in ('0', '1')]
        return filtered_bits

    def load_complexity_data(self, filepath: str) -> dict:
        with open(filepath, 'r') as f:
            complexity_data = json.load(f)
        return {int(k): v for k, v in complexity_data.items()}

    def embed_message(self, frames_dir: str, bits: List[str], noisy_blocks_map: dict, block_size: int = 4) -> Tuple[List[np.ndarray], List[Tuple]]:
        all_frame_paths = sorted(glob.glob(os.path.join(frames_dir, 'frame_*.png')))
        if not all_frame_paths:
            print(f"Error: No frames found in {frames_dir}")
            return [], []

        loaded_frames = []
        for path in all_frame_paths:
            frame = cv2.imread(path)
            if frame is None:
                print(f"Warning: Could not read frame {path}, skipping.")
                continue
            loaded_frames.append(frame)

        bit_idx = 0
        location_map = []
        
        for frame_idx, frame in enumerate(loaded_frames):
            if bit_idx >= len(bits):
                break
            
            current_frame_noisy_blocks = noisy_blocks_map.get(frame_idx, [])
            
            for (i, j) in current_frame_noisy_blocks:
                if bit_idx >= len(bits):
                    break
                    
                block_region = frame[i:i+block_size, j:j+block_size].copy()
                
                for x in range(block_size):
                    for y in range(block_size):
                        if bit_idx < len(bits):
                            for c in range(3):
                                pixel_value = int(block_region[x, y, c])
                                bit_value = int(bits[bit_idx])
                                
                                new_value = (pixel_value & 0xFC) | (bit_value * 3)
                                
                                block_region[x, y, c] = new_value
                            
                            location_map.append((frame_idx, i+x, j+y, 0)) 
                            bit_idx += 1
                
                frame[i:i+block_size, j:j+block_size] = block_region
                
            if bit_idx >= len(bits):
                break
        
        return loaded_frames, location_map

    def save_location_map(self, location_map: List[Tuple], message_length: int, path: str = 'location_map.npy'):
        np.save(path, {
            'location_map': location_map,
            'message_length': message_length
        })
        print(f"Saved location map to {path}")

    def save_stego_frames(self, frames: List[np.ndarray], output_dir: str):
        os.makedirs(output_dir, exist_ok=True)
        for i, frame in enumerate(frames):
            output_path = os.path.join(output_dir, f'frame_{i:04d}.png')
            cv2.imwrite(output_path, frame)

    def create_stego_video(self, stego_frames_dir: str, output_path: str, original_video_path: str):
        frame_paths = sorted(glob.glob(os.path.join(stego_frames_dir, 'frame_*.png')))
        if not frame_paths:
            print(f"Error: No stego frames found in {stego_frames_dir}. Cannot create stego video.")
            return

        cap_orig = cv2.VideoCapture(original_video_path)
        if not cap_orig.isOpened():
            print(f"Warning: Could not open original video {original_video_path} to get FPS. Defaulting to 30 FPS.")
            fps = 30
        else:
            fps = cap_orig.get(cv2.CAP_PROP_FPS)
            cap_orig.release()

        first_frame = cv2.imread(frame_paths[0])
        if first_frame is None:
            print(f"Error: Could not read first stego frame {frame_paths[0]}. Cannot create video.")
            return

        h, w, _ = first_frame.shape
        
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
        
        for i, frame_path in enumerate(frame_paths):
            frame = cv2.imread(frame_path)
            if frame is not None:
                out.write(frame)
        out.release()

if __name__ == "__main__":
    TEST_MESSAGE = "STEGO"
    TEST_PASSWORD = "my_secret_password"

    INPUT_VIDEO = 'output.mp4'
    OUTPUT_FRAMES_DIR = 'input_frames'
    COMPLEXITY_FILE = 'complexity.json'
    STEGO_FRAMES_DIR = 'stego_frames'
    STEGO_VIDEO_OUTPUT = 'output.avi' # Output video format is AVI
    LOCATION_MAP_OUTPUT = 'location_map.npy'
    
    BLOCK_SIZE = 4
    THRESHOLD = 0.2

    try:
        # Phase 1: Message Conversion
        bits_to_embed = message_to_bits(TEST_MESSAGE, TEST_PASSWORD)
        save_bits_to_file(bits_to_embed, "bit_message.txt")

        # Phase 2: Frame Processing and Complexity Analysis
        extracted_frame_paths = extract_frames(INPUT_VIDEO, OUTPUT_FRAMES_DIR)
        if not extracted_frame_paths:
            print("Error: No frames were extracted. Please ensure input.mp4 is a valid video file.")
            exit(1)

        process_frames_for_complexity(OUTPUT_FRAMES_DIR, BLOCK_SIZE, THRESHOLD, COMPLEXITY_FILE)

        # Phase 3: Embedding
        embedder = BPCS_Embedder()
        bits_from_file = embedder.load_bits_from_file("bit_message.txt")
        if not bits_from_file:
            print("Error: No valid bits (0 or 1) loaded from bit_message.txt. Embedding cannot proceed.")
            exit(1)

        noisy_blocks_data = embedder.load_complexity_data(COMPLEXITY_FILE)

        stego_frames_list, location_map = embedder.embed_message(
            frames_dir=OUTPUT_FRAMES_DIR, 
            bits=bits_from_file, 
            noisy_blocks_map=noisy_blocks_data, 
            block_size=BLOCK_SIZE
        )

        embedder.save_location_map(location_map, len(bits_from_file), LOCATION_MAP_OUTPUT)
        embedder.save_stego_frames(stego_frames_list, STEGO_FRAMES_DIR)
        
        # CREATE output.avi as requested
        embedder.create_stego_video(STEGO_FRAMES_DIR, STEGO_VIDEO_OUTPUT, INPUT_VIDEO)
        
        print("DONE")

    except Exception as e:
        print(f"An error occurred during the process: {e}")
    finally:
        # Clean up input_frames folder
        if os.path.exists(OUTPUT_FRAMES_DIR):
            shutil.rmtree(OUTPUT_FRAMES_DIR)
        
        # Clean up bit_message.txt and complexity.json
        if os.path.exists("bit_message.txt"):
            os.remove("bit_message.txt")
        if os.path.exists(COMPLEXITY_FILE):
            os.remove(COMPLEXITY_FILE)
        
        # Delete output.avi (since output.mp4 is not generated)
        if os.path.exists(STEGO_VIDEO_OUTPUT):
            os.remove(STEGO_VIDEO_OUTPUT)
