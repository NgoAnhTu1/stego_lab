import numpy as np
import os

def load_location_map(file_path: str):
    """
    Loads and displays information from a location_map.npy file.

    Args:
        file_path (str): The path to the location_map.npy file.

    Returns:
        dict: A dictionary containing 'location_map' (list of tuples) and 'message_length' (int).
              Raises FileNotFoundError or ValueError if file is not found or invalid.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Lỗi: Không tìm thấy file bản đồ vị trí: '{file_path}'")

    try:
        data = np.load(file_path, allow_pickle=True).item()

        if 'location_map' in data and 'message_length' in data:
            print(f"Đã tải bản đồ vị trí thành công từ: '{file_path}'")
            return data
        else:
            raise ValueError(f"Lỗi: File bản đồ vị trí không hợp lệ. Thiếu khóa 'location_map' hoặc 'message_length' trong '{file_path}'.")

    except Exception as e:
        raise Exception(f"Đã xảy ra lỗi khi đọc file bản đồ vị trí: {e}")

if __name__ == "__main__":
    location_map_file = 'location_map.npy' # Tên file location map mặc định

    print("=== ĐỌC FILE BẢN ĐỒ VỊ TRÍ ===")
    try:
        loaded_map_data = load_location_map(location_map_file)
        print(f"Độ dài tin nhắn gốc (bits): {loaded_map_data['message_length']}")
        print(f"Tổng số vị trí được ghi trong bản đồ: {len(loaded_map_data['location_map'])}")
        print("\n--- Ví dụ các mục nhập bản đồ vị trí (10 mục đầu tiên) ---")
        
        for i, entry in enumerate(loaded_map_data['location_map'][:10]):
            # Cấu trúc mục nhập: (frame_idx, row, col, channel)
            print(f"  Mục {i+1}: Frame {entry[0]}, Hàng {entry[1]}, Cột {entry[2]}, Kênh {entry[3]}")
        
        if len(loaded_map_data['location_map']) > 10:
            print(f"  ... (và {len(loaded_map_data['location_map']) - 10} mục nữa)")
            
    except (FileNotFoundError, ValueError, Exception) as e:
        print(f"Thất bại khi tải bản đồ vị trí: {e}")
