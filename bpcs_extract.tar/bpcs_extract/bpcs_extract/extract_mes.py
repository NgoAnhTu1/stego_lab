import cv2
import numpy as np
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os
import glob

class BPCS_Extractor:
    def __init__(self, password):
        self.password = password
        
    def _generate_key(self) -> bytes:
        """Generate encryption key based on the password provided during initialization."""
        salt = b'fixed_salt_for_consistency' # This salt should be consistent with the embedding process
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(self.password.encode()))
    
    def bits_to_message(self, bits: list) -> str:
        """Convert bit string back to decrypted message."""
        # Convert bits to bytes
        bytes_array = []
        for i in range(0, len(bits), 8):
            byte = 0
            for j in range(8):
                if i + j < len(bits):
                    byte |= int(bits[i + j]) << j
            bytes_array.append(byte)
        
        # Extract checksum
        if len(bytes_array) < 1:
            raise ValueError("Message too short for checksum verification.")
            
        received_checksum = bytes_array[-1]
        message_bytes = bytes_array[:-1] # Message bytes without checksum
        
        # Verify checksum
        calculated_checksum = sum(message_bytes) & 0xFF
        if calculated_checksum != received_checksum:
            print(f"Checksum mismatch: Expected {calculated_checksum}, got {received_checksum}.")
            raise ValueError("Checksum check failed during message reconstruction.")
        
        # Convert bytes to string (before decryption to find markers)
        message_with_markers = ''.join(chr(b) for b in message_bytes)
        
        # Find start/end markers
        start_idx = message_with_markers.find("START")
        end_idx = message_with_markers.find("END")
        
        if start_idx == -1 or end_idx == -1:
            raise ValueError("Start/end markers not found. Message may be corrupted or incomplete.")
            
        encrypted_message_b64 = message_with_markers[start_idx+5:end_idx] # Extract Base64 encoded part
        
        # Decrypt message
        key = self._generate_key()
        f = Fernet(key)
        
        try:
            decrypted_message = f.decrypt(encrypted_message_b64.encode())
            return decrypted_message.decode()
        except Exception as e:
            print(f"Decryption failed: {e}")
            raise ValueError("Decryption failed. Incorrect password or corrupted message.")

    def load_location_map(self, path: str = 'location_map.npy') -> dict:
        """Load location map from file."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"Location map file not found: {path}")
        data = np.load(path, allow_pickle=True).item()
        
        if 'location_map' not in data or 'message_length' not in data:
            raise ValueError(f"Invalid location map file format. Missing 'location_map' or 'message_length' key in {path}")
            
        print(f"Loaded location map from: {path} with {len(data['location_map'])} points.")
        return data

    def load_stego_frames(self, input_dir: str) -> list:
        """Load stego frames from PNG images."""
        print(f"Loading stego frames from {input_dir}...")
        frame_paths = sorted(glob.glob(os.path.join(input_dir, 'frame_*.png')))
        if not frame_paths:
            raise FileNotFoundError(f"No stego frames found in directory: {input_dir}")
            
        frames = []
        for i, frame_path in enumerate(frame_paths):
            frame = cv2.imread(frame_path)
            if frame is None:
                print(f"Warning: Could not read frame {frame_path}, skipping.")
                continue
            frames.append(frame)
            if i % 100 == 0 and i != 0:
                print(f"  Loaded {i} frames...")
        print(f"Finished loading {len(frames)} stego frames.")
        return frames
        
    def extract_message(self, frames: list, location_map_data: dict) -> str:
        """Extract hidden message from frames using location map."""
        bits = []
        location_map = location_map_data['location_map']
        message_length_expected = location_map_data['message_length']
        
        print(f"Extracting {message_length_expected} bits using {len(location_map)} locations...")

        # Limit the number of locations processed to the expected message length if location_map is larger
        # This is important to avoid reading extra bits that might not be part of the message.
        if len(location_map) > message_length_expected:
            print(f"Warning: Location map has {len(location_map)} entries, but expected message length is {message_length_expected} bits.")
            location_map_to_process = location_map[:message_length_expected]
        else:
            location_map_to_process = location_map
        
        # Use a dict for faster frame lookup if there are many frames and scattered locations
        # Or just iterate through location_map and load frames as needed (less memory intensive)
        # Given frames are loaded in load_stego_frames, it's probably better to keep them in list/array
        
        for bit_idx_in_map, (frame_idx, i, j, _) in enumerate(location_map_to_process):
            if frame_idx >= len(frames):
                print(f"Warning: Location map points to frame {frame_idx} which is beyond loaded frames count ({len(frames)}). Stopping extraction.")
                break # Stop if we run out of frames

            frame = frames[frame_idx]

            # Check if pixel coordinates are within frame bounds
            if not (0 <= i < frame.shape[0] and 0 <= j < frame.shape[1]):
                print(f"Warning: Location map points to out-of-bounds pixel ({i}, {j}) in frame {frame_idx}. Skipping this bit.")
                continue

            # Lấy bit từ cả 3 kênh màu và sử dụng 2 bit LSB
            bits_from_channels = []
            for c in range(3): # Iterate through BGR channels
                pixel_value = int(frame[i, j, c])
                # Lấy 2 bit LSB và chuyển thành 1 bit (0 hoặc 1)
                # Recall from embedding: bit_value * 3 means 0 -> 0b00, 1 -> 0b11.
                # So, if LSBs are 0b00, bit_value is 0. If LSBs are 0b11, bit_value is 1.
                # (pixel_value & 0x03) gives the two LSBs.
                # If the LSBs are 0b00, then (0b00 >> 1) is 0.
                # If the LSBs are 0b11, then (0b11 >> 1) is 1.
                lsb_pair = (pixel_value & 0x03)
                
                # This logic needs to accurately reverse the embedding logic.
                # If original embedding did `(pixel_value & 0xFC) | (bit_value * 3)`
                # Then to extract, we look at `(pixel_value & 0x03)`
                # If it's 0x00, extracted bit is 0. If it's 0x03, extracted bit is 1.
                extracted_bit = 1 if lsb_pair == 0x03 else 0 # Or 0 if lsb_pair == 0x00
                # Handle cases where LSBs might not be 0x00 or 0x03 (due to noise/corruption)
                # In such cases, the original code took the most frequent bit from the 3 channels.
                
                bits_from_channels.append(str(extracted_bit))
            
            # Sử dụng bit phổ biến nhất từ 3 kênh màu
            if bits_from_channels: # Ensure list is not empty
                bit = max(set(bits_from_channels), key=bits_from_channels.count)
                bits.append(bit)
            else:
                print(f"Warning: No bits extracted from pixel ({i}, {j}) in frame {frame_idx}. Skipping.")

            if (bit_idx_in_map + 1) % 10000 == 0:
                print(f"  Extracted {bit_idx_in_map + 1}/{len(location_map_to_process)} bits...")
            
            # Stop if we have extracted enough bits as per message_length_expected
            if len(bits) >= message_length_expected:
                break

        # Ensure we only pass the expected number of bits to bits_to_message
        if len(bits) < message_length_expected:
            print(f"Warning: Extracted only {len(bits)} bits, less than expected {message_length_expected}.")
        
        try:
            return self.bits_to_message(bits[:message_length_expected])
        except ValueError as e:
            print(f"Error during message reconstruction: {e}")
            print(f"Extracted bits (first 100): {bits[:100]}")
            raise # Re-raise the exception after printing debug info

    def create_decoded_video(self, stego_frames_dir: str, output_path: str, original_video_path: str = None):
        """
        Create video from stego frames (which are the 'decoded' frames after extraction).
        This function is similar to create_stego_video in embedder, but names imply decoding.
        """
        frame_paths = sorted(glob.glob(os.path.join(stego_frames_dir, 'frame_*.png')))
        if not frame_paths:
            print(f"Error: No frames found in {stego_frames_dir}. Cannot create decoded video.")
            return

        # Get FPS from original video or default to 30
        fps = 30
        if original_video_path and os.path.exists(original_video_path):
            cap_orig = cv2.VideoCapture(original_video_path)
            if cap_orig.isOpened():
                fps = cap_orig.get(cv2.CAP_PROP_FPS)
                cap_orig.release()
            else:
                print(f"Warning: Could not open original video {original_video_path} to get FPS. Using default {fps} FPS.")
        else:
            print(f"Warning: Original video path not provided or found. Using default {fps} FPS for decoded video.")

        # Read the first frame to get dimensions
        first_frame = cv2.imread(frame_paths[0])
        if first_frame is None:
            print(f"Error: Could not read first frame {frame_paths[0]}. Cannot create video.")
            return

        h, w, _ = first_frame.shape
        
        # Use XVID codec for broad compatibility
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
        
        print(f"Creating decoded video '{output_path}' with {len(frame_paths)} frames at {fps} FPS...")
        for i, frame_path in enumerate(frame_paths):
            frame = cv2.imread(frame_path)
            if frame is not None:
                out.write(frame)
            else:
                print(f"Warning: Skipping missing frame {frame_path}")
            if i % 100 == 0 and i != 0:
                print(f"  Added frame {i} to video...")
        out.release()
        print(f"Successfully created decoded video: {output_path}")


if __name__ == "__main__":
    # --- Configuration ---
    STEGO_FRAMES_DIR = 'stego_frames'  # Thư mục chứa các frame đã giấu tin
    LOCATION_MAP_FILE = 'location_map.npy'
    PASSWORD = 'my_secret_password' # Phải khớp với mật khẩu dùng khi giấu tin
    DECODED_VIDEO_OUTPUT = os.path.join(STEGO_FRAMES_DIR, 'decoded_video.avi') # Video giải mã sẽ nằm trong thư mục stego_frames
    ORIGINAL_VIDEO_PATH = 'input.mp4' # Cần cung cấp đường dẫn video gốc nếu muốn lấy FPS chính xác

    print("\n=== EXTRACTION PROCESS ===")

    extractor = BPCS_Extractor(PASSWORD)

    try:
        # Bước 1: Tải bản đồ vị trí
        location_map_data = extractor.load_location_map(LOCATION_MAP_FILE)

        # Bước 2: Tải các khung hình đã giấu tin
        stego_frames = extractor.load_stego_frames(STEGO_FRAMES_DIR)

        # Bước 3: Trích xuất tin nhắn
        extracted_message = extractor.extract_message(stego_frames, location_map_data)
        
        if extracted_message:
            print(f"\nExtracted message: \"{extracted_message}\"")
            print(f"Extraction successful!")

            # Bước 4: Tạo video đã giải mã từ các khung hình đã giấu tin (stego_frames)
            # stego_frames chính là các frames mà tin nhắn đã được lấy ra.
            extractor.create_decoded_video(STEGO_FRAMES_DIR, DECODED_VIDEO_OUTPUT, ORIGINAL_VIDEO_PATH)
        else:
            print("\nMessage extraction failed or returned empty.")

    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure that 'stego_frames' folder and 'location_map.npy' file exist and are in the correct directory.")
    except ValueError as e:
        print(f"Error during extraction process: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")