import cv2
import os
import sys
import csv

# --- Helper functions ---
def read_bits(bits_file):
    with open(bits_file, 'r') as f:
        bits = [int(b) for b in f.read().strip()]
    return bits

def load_rli_blocks(rli_map_file, rli_threshold):
    rli_blocks = []
    with open(rli_map_file, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            frame_idx = int(row['frame_idx'])
            i = int(row['block_i'])
            j = int(row['block_j'])
            rli = float(row['rli'])
            if rli > rli_threshold:
                rli_blocks.append((frame_idx, i, j))
    return rli_blocks

def embed_bits_to_frames(input_frames_dir, bits, rli_blocks, block_size, stego_frames_dir):
    frame_files = sorted([f for f in os.listdir(input_frames_dir) if f.endswith('.png')])
    frames = [cv2.imread(os.path.join(input_frames_dir, fname)) for fname in frame_files]
    os.makedirs(stego_frames_dir, exist_ok=True)
    bit_idx = 0
    for (frame_idx, i, j) in rli_blocks:
        if bit_idx >= len(bits):
            break
        frame = frames[frame_idx]
        block = frame[i:i+block_size, j:j+block_size].copy()
        for x in range(block_size):
            for y in range(block_size):
                if bit_idx < len(bits):
                    for c in range(3):
                        pixel_value = int(block[x, y, c])
                        bit_value = bits[bit_idx]
                        new_value = (pixel_value & 0xFE) | bit_value
                        block[x, y, c] = new_value
                    bit_idx += 1
        frame[i:i+block_size, j:j+block_size] = block
    # Lưu các frame đã nhúng
    for idx, frame in enumerate(frames):
        out_path = os.path.join(stego_frames_dir, f'frame_{idx:04d}.png')
        cv2.imwrite(out_path, frame)
    print(f"Đã nhúng {bit_idx} bits vào {len(frames)} frames. Lưu vào {stego_frames_dir}")
    return frames

def create_stego_video(frames, output_path, fps):
    if not frames:
        raise ValueError("Danh sách frames rỗng, không thể tạo video.")
    h, w, _ = frames[0].shape
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
    for frame in frames:
        out.write(frame)
    out.release()
    print(f"Đã tạo video stego: {output_path}")

if __name__ == "__main__":
    input_frames_dir = "extract_frames"
    bits_file = "bits_mes.txt"
    rli_map_file = "rli_map.csv"
    rli_threshold = 0.2
    block_size = 8
    stego_frames_dir = "stego_frames"
    output_video = "output.avi"
    bits = read_bits(bits_file)
    rli_blocks = load_rli_blocks(rli_map_file, rli_threshold)
    frames = embed_bits_to_frames(input_frames_dir, bits, rli_blocks, block_size, stego_frames_dir)
    # Lấy fps từ frame gốc
    video_files = sorted([f for f in os.listdir(input_frames_dir) if f.endswith('.png')])
    if video_files:
        first_frame = cv2.imread(os.path.join(input_frames_dir, video_files[0]))
        h, w, _ = first_frame.shape
        # Giả sử 30fps nếu không có video gốc
        fps = 30
        create_stego_video(frames, output_video, fps)
    print("--- Done ---") 