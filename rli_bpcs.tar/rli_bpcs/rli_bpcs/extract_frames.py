import cv2
import os
import sys

def extract_frames(video_path, output_dir):
    cap = cv2.VideoCapture(video_path)
    frames = []
    idx = 0
    os.makedirs(output_dir, exist_ok=True)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_path = os.path.join(output_dir, f'frame_{idx:04d}.png')
        cv2.imwrite(frame_path, frame)
        frames.append(frame)
        idx += 1
    cap.release()
    print(f"Đã tách {len(frames)} frames từ {video_path} và lưu vào {output_dir}")
    return frames

if __name__ == "__main__":
    video_path = "input.mp4"
    output_dir = "extract_frames"
    extract_frames(video_path, output_dir) 