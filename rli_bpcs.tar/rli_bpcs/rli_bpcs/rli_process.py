import cv2
import numpy as np
import os
import sys
import csv

def calculate_rli(block):
    n = block.shape[0]
    run_lengths = []
    for i in range(n):
        row = block[i, :]
        prev = row[0]
        run = 1
        for j in range(1, n):
            if row[j] == prev:
                run += 1
            else:
                run_lengths.append(run)
                run = 1
                prev = row[j]
        run_lengths.append(run)
    for j in range(n):
        col = block[:, j]
        prev = col[0]
        run = 1
        for i in range(1, n):
            if col[i] == prev:
                run += 1
            else:
                run_lengths.append(run)
                run = 1
                prev = col[i]
        run_lengths.append(run)
    num_runs = len(run_lengths)
    min_runs = 2 * n
    max_runs = 2 * n * n
    beta = (num_runs - min_runs) / (max_runs - min_runs)
    return beta

def process_rli(input_frames_dir, block_size, rli_threshold, rli_map_file):
    frame_files = sorted([f for f in os.listdir(input_frames_dir) if f.endswith('.png')])
    with open(rli_map_file, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['frame_idx', 'block_i', 'block_j', 'rli'])
        for frame_idx, fname in enumerate(frame_files):
            frame = cv2.imread(os.path.join(input_frames_dir, fname))
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape
            for i in range(0, h-block_size+1, block_size):
                for j in range(0, w-block_size+1, block_size):
                    block = gray[i:i+block_size, j:j+block_size]
                    rli = calculate_rli(block)
                    writer.writerow([frame_idx, i, j, rli])
    print(f"Đã tính RLI cho các block và lưu vào {rli_map_file}")
    # Lọc block đủ ngưỡng (có thể dùng file này cho embed)
    # Nếu muốn chỉ lưu block đủ ngưỡng, hãy lọc khi ghi file

if __name__ == "__main__":
    input_frames_dir = "extract_frames"
    block_size = 8
    rli_threshold = 0.2
    rli_map_file = "rli_map.csv"
    process_rli(input_frames_dir, block_size, rli_threshold, rli_map_file) 