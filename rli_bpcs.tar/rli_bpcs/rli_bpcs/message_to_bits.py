def message_to_bits(message):
    bytes_array = [ord(c) for c in message]
    checksum = sum(bytes_array) & 0xFF
    bytes_array.append(checksum)
    bits = []
    for b in bytes_array:
        for i in range(8):
            bits.append(str((b >> i) & 1))
    return bits

if __name__ == "__main__":
    message = "STEGO"
    bits = message_to_bits(message)
    with open("bits_mes.txt", "w") as f:
        f.write("".join(bits))
    print(f"Đã chuyển thông điệp thành {len(bits)} bits và lưu vào bits_mes.txt") 