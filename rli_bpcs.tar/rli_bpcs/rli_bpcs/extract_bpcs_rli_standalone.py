import cv2
import numpy as np
import os
import csv

# --- Config ---
stego_frames_dir = 'stego_frames'
block_size = 8
rli_threshold = 0.2
message_length = 5  
rli_map_file = 'rli_map.csv'

# --- Helper functions ---
def get_bit_plane(frame, plane_idx=0):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return (gray >> plane_idx) & 1

def calculate_rli(block):
    n = block.shape[0]
    run_lengths = []
    for i in range(n):
        row = block[i, :]
        prev = row[0]
        run = 1
        for j in range(1, n):
            if row[j] == prev:
                run += 1
            else:
                run_lengths.append(run)
                run = 1
                prev = row[j]
        run_lengths.append(run)
    for j in range(n):
        col = block[:, j]
        prev = col[0]
        run = 1
        for i in range(1, n):
            if col[i] == prev:
                run += 1
            else:
                run_lengths.append(run)
                run = 1
                prev = col[i]
        run_lengths.append(run)
    num_runs = len(run_lengths)
    min_runs = 2 * n
    max_runs = 2 * n * n
    beta = (num_runs - min_runs) / (max_runs - min_runs)
    return beta

def find_high_rli_blocks(bit_plane, block_size, rli_threshold):
    h, w = bit_plane.shape
    high_rli_blocks = []
    for i in range(0, h-block_size+1, block_size):
        for j in range(0, w-block_size+1, block_size):
            block = bit_plane[i:i+block_size, j:j+block_size]
            rli = calculate_rli(block)
            if rli > rli_threshold:
                high_rli_blocks.append((i, j))
    return high_rli_blocks

def load_stego_frames(stego_frames_dir):
    frame_files = sorted([f for f in os.listdir(stego_frames_dir) if f.endswith('.png')])
    frames = []
    for fname in frame_files:
        frame = cv2.imread(os.path.join(stego_frames_dir, fname))
        frames.append(frame)
    return frames

def load_rli_map(rli_map_file, rli_threshold):
    rli_blocks = []
    with open(rli_map_file, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            frame_idx = int(row['frame_idx'])
            i = int(row['block_i'])
            j = int(row['block_j'])
            rli = float(row['rli'])
            if rli > rli_threshold:
                rli_blocks.append((frame_idx, i, j))
    return rli_blocks

def extract_bits_from_rli_map(frames, rli_blocks, block_size=8, max_bits=None):
    bits = []
    for (frame_idx, i, j) in rli_blocks:
        frame = frames[frame_idx]
        for x in range(block_size):
            for y in range(block_size):
                pixel = frame[i+x, j+y]
                bit = pixel[0] & 1
                bits.append(bit)
                if max_bits and len(bits) >= max_bits:
                    return bits
    return bits

def bits_to_message(bits):
    bytes_array = []
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            if i + j < len(bits):
                byte |= int(bits[i + j]) << j
        bytes_array.append(byte)
    if len(bytes_array) < 2:
        return ''
    received_checksum = bytes_array[-1]
    message_bytes = bytes_array[:-1]
    calculated_checksum = sum(message_bytes) & 0xFF
    if calculated_checksum != received_checksum:
        print(f"Checksum mismatch: expected {calculated_checksum}, got {received_checksum}")
        return ''
    try:
        message = ''.join(chr(b) for b in message_bytes)
        return message
    except Exception as e:
        print(f"Decode error: {e}")
        return ''

# --- Main ---
if __name__ == "__main__":
    print("--- Extract BPCS+RLI Message from stego_frames using rli_map.csv ---")
    frames = load_stego_frames(stego_frames_dir)
    print(f"Loaded {len(frames)} stego frames")
    rli_blocks = load_rli_map(rli_map_file, rli_threshold)
    print(f"Loaded {len(rli_blocks)} RLI blocks from map")
    max_bits = None
    if message_length:
        max_bits = (message_length + 1) * 8
    bits = extract_bits_from_rli_map(frames, rli_blocks, block_size=block_size, max_bits=max_bits)
    print(f"Extracted {len(bits)} bits")
    message = bits_to_message(bits)
    print(f"Extracted message: {message}")
    print("--- Done ---") 