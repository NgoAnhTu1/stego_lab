import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os

def _generate_key(password: str) -> bytes:
    """Generate encryption key from password."""
    salt = b'fixed_salt_for_consistency'
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def message_to_bits(message: str, password: str) -> list:
    """Convert message to encrypted bit string."""
    key = _generate_key(password)
    f = Fernet(key)
    encrypted_message = f.encrypt(message.encode())
    
    # Add start/end markers for reliable extraction
    message_with_markers = "START" + encrypted_message.decode() + "END"
    
    bytes_array = [ord(c) for c in message_with_markers]
    
    # Calculate simple checksum
    checksum = sum(bytes_array) & 0xFF
    bytes_array.append(checksum)
    
    # Convert to bits (LSB first)
    bits = []
    for b in bytes_array:
        for i in range(8):
            bits.append(str((b >> i) & 1))
    
    return bits

def save_bits_to_file(bits: list, filename: str):
    """Save a list of bit strings to a text file."""
    with open(filename, 'w') as f:
        f.write("".join(bits))
    print(f"Saved {len(bits)} bits to {filename}")

if __name__ == "__main__":
    test_message = "STEGO"
    test_password = "my_secret_password"
    output_filename = "bit_message.txt"

    print("\n=== MESSAGE CONVERSION PROCESS ===")
    print(f"Original message: \"{test_message}\"")
    print(f"Using password: \"{test_password}\"")

    bits = message_to_bits(test_message, test_password)
    save_bits_to_file(bits, output_filename)
    print("Message conversion completed.")