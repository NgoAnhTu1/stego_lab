import hashlib
import sys
import os

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Vui lòng cung cấp đường dẫn file. Ví dụ: python3 hash_calculator.py ten_file.txt")
        sys.exit(1)

    file_path = sys.argv[1]

    if not os.path.exists(file_path):
        print("Lỗi: Không tìm thấy file.")
        sys.exit(1)

    sha256_hash = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        print(sha256_hash.hexdigest())
    except Exception as e:
        print(f"Lỗi khi đọc file: {e}")
        sys.exit(1)