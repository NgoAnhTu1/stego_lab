import cv2
import numpy as np
import os
import json
import glob
from typing import List, Tuple # Import List and Tuple from the typing module

class BPCS_Embedder:
    def __init__(self):
        # No password needed here as encryption is handled in message_converter.py
        pass

    def load_bits_from_file(self, filename: str) -> List[str]: # Changed type hint
        """Load bit string from a text file."""
        with open(filename, 'r') as f:
            bits_str = f.read().strip()
        return list(bits_str)

    def load_complexity_data(self, filepath: str) -> dict:
        """Load noisy blocks data from a JSON file."""
        with open(filepath, 'r') as f:
            complexity_data = json.load(f)
        # Convert string keys (frame indices) back to int if needed, or keep as string for direct lookup
        return {int(k): v for k, v in complexity_data.items()}

    def embed_message(self, frames_dir: str, bits: List[str], noisy_blocks_map: dict, block_size: int = 4) -> Tuple[List[np.ndarray], List[Tuple]]: # Changed type hint
        """
        Embeds bits into the noisy blocks of frames.
        
        Args:
            frames_dir: Directory containing the extracted frames.
            bits: The list of bits to embed.
            noisy_blocks_map: A dictionary mapping frame_idx to a list of (row, col) of noisy blocks.
            block_size: The size of the blocks (e.g., 4x4 or 8x8).
            
        Returns:
            A tuple containing:
                - List of modified frames (as cv2 images).
                - The location map as a list of (frame_idx, row, col, color_channel) tuples.
        """
        all_frame_paths = sorted(glob.glob(os.path.join(frames_dir, 'frame_*.png')))
        if not all_frame_paths:
            print(f"Error: No frames found in {frames_dir}")
            return [], []

        loaded_frames = []
        # Load all frames into memory first for easier modification
        print(f"Loading {len(all_frame_paths)} frames from {frames_dir} for embedding...")
        for path in all_frame_paths:
            frame = cv2.imread(path)
            if frame is None:
                print(f"Warning: Could not read frame {path}, skipping.")
                continue
            loaded_frames.append(frame)
        print("All frames loaded.")

        bit_idx = 0
        location_map = []
        
        print(f"Total bits to embed: {len(bits)}")
        
        for frame_idx, frame in enumerate(loaded_frames):
            if bit_idx >= len(bits):
                print(f"Message fully embedded. Remaining frames not processed.")
                break
            
            if frame_idx % 100 == 0:
                print(f"Embedding into frame {frame_idx}/{len(loaded_frames)}")
            
            current_frame_noisy_blocks = noisy_blocks_map.get(frame_idx, [])
            
            for (i, j) in current_frame_noisy_blocks:
                if bit_idx >= len(bits):
                    break
                    
                block_region = frame[i:i+block_size, j:j+block_size].copy()
                
                for x in range(block_size):
                    for y in range(block_size):
                        if bit_idx < len(bits):
                            # Embed bit into all 3 color channels using 2 LSBs as per original logic
                            for c in range(3): # Iterate through BGR channels
                                pixel_value = int(block_region[x, y, c])
                                bit_value = int(bits[bit_idx])
                                
                                # Embed bit into 2 LSBs
                                # The original embedding: 0 -> 0b00, 1 -> 0b11.
                                new_value = (pixel_value & 0xFC) | (bit_value * 3)
                                
                                block_region[x, y, c] = new_value
                            
                            # Record the pixel location in the location map (frame_idx, row, col, channel)
                            location_map.append((frame_idx, i+x, j+y, 0)) 
                            bit_idx += 1
                
                frame[i:i+block_size, j:j+block_size] = block_region
                
            if bit_idx >= len(bits):
                print(f"Message fully embedded at frame {frame_idx}")
                break
        
        print(f"Embedding completed. Total bits embedded: {bit_idx}/{len(bits)}")
        return loaded_frames, location_map

    def save_location_map(self, location_map: List[Tuple], message_length: int, path: str = 'location_map.npy'): # Changed type hint
        """Save location map to file."""
        np.save(path, {
            'location_map': location_map,
            'message_length': message_length
        })
        print(f"Saved location map to {path}")

    def save_stego_frames(self, frames: List[np.ndarray], output_dir: str): # Changed type hint
        """Save stego frames as PNG images."""
        os.makedirs(output_dir, exist_ok=True)
        print(f"Saving {len(frames)} stego frames to {output_dir}...")
        for i, frame in enumerate(frames):
            output_path = os.path.join(output_dir, f'frame_{i:04d}.png')
            cv2.imwrite(output_path, frame)
            if i % 100 == 0:
                print(f"  Saved frame {i}...")
        print("All stego frames saved.")

    def create_stego_video(self, stego_frames_dir: str, output_path: str, original_video_path: str):
        """Create video from stego frames."""
        frame_paths = sorted(glob.glob(os.path.join(stego_frames_dir, 'frame_*.png')))
        if not frame_paths:
            print(f"Error: No stego frames found in {stego_frames_dir}. Cannot create stego video.")
            return

        # Get FPS from the original video
        cap_orig = cv2.VideoCapture(original_video_path)
        if not cap_orig.isOpened():
            print(f"Warning: Could not open original video {original_video_path} to get FPS. Defaulting to 30 FPS.")
            fps = 30
        else:
            fps = cap_orig.get(cv2.CAP_PROP_FPS)
            cap_orig.release()

        # Read the first frame to get dimensions
        first_frame = cv2.imread(frame_paths[0])
        if first_frame is None:
            print(f"Error: Could not read first stego frame {frame_paths[0]}. Cannot create video.")
            return

        h, w, _ = first_frame.shape
        
        # Use XVID codec for broad compatibility
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
        
        print(f"Creating stego video '{output_path}' with {len(frame_paths)} frames at {fps} FPS...")
        for i, frame_path in enumerate(frame_paths):
            frame = cv2.imread(frame_path)
            if frame is not None:
                out.write(frame)
            else:
                print(f"Warning: Skipping missing stego frame {frame_path}")
            if i % 100 == 0:
                print(f"  Added frame {i} to video...")
        out.release()
        print(f"Successfully created stego video: {output_path}")

if __name__ == "__main__":
    # --- Configuration ---
    MESSAGE_FILE = "bit_message.txt"
    COMPLEXITY_FILE = "complexity.json"
    INPUT_VIDEO = 'input.mp4' # Path to your original input video
    INPUT_FRAMES_DIR = 'input_frames' # Directory where extracted frames are saved
    STEGO_FRAMES_DIR = 'stego_frames' # Directory to save stego frames
    STEGO_VIDEO_OUTPUT = 'output.avi'
    LOCATION_MAP_OUTPUT = 'location_map.npy'
    
    BLOCK_SIZE = 4  # Default block size from original script
    # Threshold is used in frame_processor, not directly here

    print("\n=== EMBEDDING PROCESS ===")

    embedder = BPCS_Embedder()

    # Step 1: Load bits from file (generated by message_converter.py)
    print(f"Loading message bits from {MESSAGE_FILE}...")
    bits_to_embed = embedder.load_bits_from_file(MESSAGE_FILE)
    print(f"Loaded {len(bits_to_embed)} bits.")

    # Step 2: Load complexity data (generated by frame_processor.py)
    print(f"Loading complexity data from {COMPLEXITY_FILE}...")
    noisy_blocks_data = embedder.load_complexity_data(COMPLEXITY_FILE)
    print(f"Loaded complexity data for {len(noisy_blocks_data)} frames.")

    # Step 3: Embed the message into the frames
    # The embed_message function will load frames from INPUT_FRAMES_DIR
    print("Starting message embedding into frames...")
    stego_frames_list, location_map = embedder.embed_message(
        frames_dir=INPUT_FRAMES_DIR, 
        bits=bits_to_embed, 
        noisy_blocks_map=noisy_blocks_data, 
        block_size=BLOCK_SIZE
    )

    # Step 4: Save location map
    embedder.save_location_map(location_map, len(bits_to_embed), LOCATION_MAP_OUTPUT)

    # Step 5: Save stego frames
    embedder.save_stego_frames(stego_frames_list, STEGO_FRAMES_DIR)

    # Step 6: Create stego video
    embedder.create_stego_video(STEGO_FRAMES_DIR, STEGO_VIDEO_OUTPUT, INPUT_VIDEO)
    
    print("\nEmbedding process completed successfully!")
