import cv2
import numpy as np
import os
import json
import glob
import shutil # Thêm thư viện shutil để xóa thư mục

def extract_frames(video_path: str, output_dir: str):
    """Extract frames from video and save them as PNG images."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video file {video_path}")
        return []

    # Xóa thư mục output_dir nếu nó tồn tại, sau đó tạo lại
    if os.path.exists(output_dir):
        print(f"Cleaning existing frames in {output_dir}...")
        shutil.rmtree(output_dir) # Xóa thư mục và tất cả nội dung bên trong
    os.makedirs(output_dir, exist_ok=True) # Tạo lại thư mục

    frames = []
    frame_count = 0
    
    print(f"Extracting frames from {video_path} to {output_dir}...")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_filename = os.path.join(output_dir, f"frame_{frame_count:04d}.png")
        cv2.imwrite(frame_filename, frame)
        frames.append(frame_filename) # Store path to the frame
        frame_count += 1
        if frame_count % 100 == 0:
            print(f"  Extracted {frame_count} frames...")
    
    cap.release()
    print(f"Finished extracting {frame_count} frames.")
    return frames # Return list of saved frame paths

def _get_bit_planes(frame: np.ndarray) -> list:
    """Split frame into bit planes."""
    # Convert to grayscale for complexity calculation as per BPCS theory
    if len(frame.shape) == 3: # If it's a color image
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else: # Already grayscale
        gray = frame

    bit_planes = []
    for i in range(8):
        bit_plane = (gray >> i) & 1
        bit_planes.append(bit_plane)
    return bit_planes

def _calculate_complexity(block: np.ndarray) -> float:
    """Calculate block complexity (alpha value)."""
    n = block.shape[0]
    k = 0
    
    # Count bit transitions horizontally
    for i in range(n):
        for j in range(n-1):
            if block[i, j] != block[i, j+1]:
                k += 1
    
    # Count bit transitions vertically
    for i in range(n-1):
        for j in range(n):
            if block[i, j] != block[i+1, j]:
                k += 1
    
    denominator = (2 * n * (2 * n - 1))
    if denominator == 0: # Avoid division by zero
        return 0.0
    return k / denominator

def _find_noisy_blocks(frame: np.ndarray, block_size: int = 8, threshold: float = 0.3) -> list:
    """Find noisy blocks in frame."""
    bit_planes = _get_bit_planes(frame) # Gọi trực tiếp hàm _get_bit_planes
    bit_plane = bit_planes[0] # Use the first bit plane (LSB) for complexity calculation
    h, w = bit_plane.shape
    noisy_blocks = []
    
    for i in range(0, h - block_size + 1, block_size):
        for j in range(0, w - block_size + 1, block_size):
            block = bit_plane[i:i+block_size, j:j+block_size]
            alpha = _calculate_complexity(block) # Gọi trực tiếp hàm _calculate_complexity
            if alpha > threshold:
                noisy_blocks.append((i, j))
    
    return noisy_blocks

def process_frames_for_complexity(input_frames_dir: str, block_size: int = 8, threshold: float = 0.3, output_json_path: str = 'complexity.json'):
    """
    Processes extracted frames, calculates complexity of blocks, and saves noisy blocks information.
    This version does NOT print detailed block information to the console, only summary progress.
    """
    frame_paths = sorted(glob.glob(os.path.join(input_frames_dir, 'frame_*.png')))
    if not frame_paths:
        print(f"Error: No frames found in {input_frames_dir}")
        return

    noisy_blocks_for_json = {}
    print(f"Processing {len(frame_paths)} frames for complexity...")

    for frame_idx, frame_path in enumerate(frame_paths):
        frame = cv2.imread(frame_path)
        if frame is None:
            print(f"Warning: Could not read frame {frame_path}, skipping.")
            continue
        
        # Get the LSB bit plane for complexity calculation
        bit_planes = _get_bit_planes(frame)
        bit_plane = bit_planes[0] # Using the first bit plane (LSB)

        h, w = bit_plane.shape
        current_frame_noisy_blocks_coords = [] 
        
        block_counter = 0
        for i in range(0, h - block_size + 1, block_size):
            for j in range(0, w - block_size + 1, block_size):
                block_data = bit_plane[i:i+block_size, j:j+block_size]
                
                if block_data.size == 0:
                    continue

                alpha = _calculate_complexity(block_data)
                is_noisy = alpha > threshold

                if is_noisy:
                    current_frame_noisy_blocks_coords.append((i, j))
                
                block_counter += 1
        
        # Print summary for the frame
        # Calculate total possible blocks in the frame
        total_possible_blocks = (h // block_size) * (w // block_size)
        print(f"  Processed Frame {frame_idx}: Found {len(current_frame_noisy_blocks_coords)} noisy blocks out of approx. {total_possible_blocks} total blocks.")
        
        # Store only the noisy block coordinates for JSON, for compatibility with embedder.py
        noisy_blocks_for_json[str(frame_idx)] = current_frame_noisy_blocks_coords
        
        # Keep the 100-frame progress indicator
        if frame_idx % 100 == 0 and frame_idx != 0: 
            print(f"\n  Overall progress: {frame_idx}/{len(frame_paths)} frames processed.")

    with open(output_json_path, 'w') as f:
        json.dump(noisy_blocks_for_json, f, indent=4)
    print(f"\nComplexity analysis completed. Saved noisy blocks data (coordinates only) to {output_json_path}")

if __name__ == "__main__":
    input_video_path = 'input.mp4'  # Replace with your input video path
    output_frames_dir = 'input_frames' # Folder to save extracted frames
    complexity_output_json = 'complexity.json'
    block_size = 4 # Default block size from the original embed_video call
    threshold = 0.2 # Default threshold from the original embed_video call

    print("\n=== FRAME PROCESSING AND COMPLEXITY ANALYSIS PROCESS ===")
    
    # Step 1: Extract frames
    extracted_frame_paths = extract_frames(input_video_path, output_frames_dir)
    
    # Step 2: Process frames for complexity
    if extracted_frame_paths:
        process_frames_for_complexity(output_frames_dir, block_size, threshold, complexity_output_json)
    else:
        print("No frames were extracted, skipping complexity analysis.")