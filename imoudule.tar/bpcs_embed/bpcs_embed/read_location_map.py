import numpy as np
import os

def read_location_map(file_path: str):
    """
    Reads and displays information from a location_map.npy file.

    Args:
        file_path (str): The path to the location_map.npy file.
    """
    if not os.path.exists(file_path):
        print(f"Error: The file '{file_path}' was not found.")
        return

    try:
        # np.load returns a dictionary-like object if it was saved using np.save with a dictionary
        data = np.load(file_path, allow_pickle=True).item()

        if 'location_map' in data and 'message_length' in data:
            location_map = data['location_map']
            message_length = data['message_length']

            print(f"Successfully loaded location map from: '{file_path}'")
            print(f"Original message length (in bits): {message_length}")
            print(f"Total locations recorded in map: {len(location_map)}")
            print("\n--- Sample of Location Map Entries (first 10 entries) ---")
            
            for i, entry in enumerate(location_map[:10]):
                # Entry format is (frame_idx, row, col, channel)
                print(f"  Entry {i+1}: Frame {entry[0]}, Row {entry[1]}, Col {entry[2]}, Channel {entry[3]}")
            
            if len(location_map) > 10:
                print(f"  ... (and {len(location_map) - 10} more entries)")
            
            print("\n--- Structure of a Location Map Entry ---")
            print("Each entry typically is a tuple: (frame_index, row_coordinate, column_coordinate, color_channel)")
            print("  - frame_index: The index of the video frame where the bit was embedded.")
            print("  - row_coordinate: The row (Y-coordinate) of the pixel within the frame.")
            print("  - column_coordinate: The column (X-coordinate) of the pixel within the frame.")
            print("  - color_channel: The color channel (e.g., 0 for Blue, 1 for Green, 2 for Red, or 0 if embedding affects all channels generally).")

        else:
            print(f"Error: Expected 'location_map' and 'message_length' keys in '{file_path}'.")
            print(f"File content keys: {data.keys()}")

    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

if __name__ == "__main__":
    location_map_file = 'location_map.npy' # Tên file location map mặc định
    print("=== READING LOCATION MAP FILE ===")
    read_location_map(location_map_file)